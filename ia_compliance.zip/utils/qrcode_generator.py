
import qrcode
import streamlit as st
from io import BytesIO

def gerar_qr_code(url):
    qr = qrcode.make(url)
    buf = BytesIO()
    qr.save(buf, format="PNG")
    st.image(buf.getvalue(), caption="Aponte a câmera para acessar o formulário")
